import os

#pygame window width and height
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 500

PATH = os.path.abspath(__file__)
PATH = PATH[0:-9] #-10 to chop off config.py
